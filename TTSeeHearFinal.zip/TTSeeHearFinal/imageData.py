class ImageData:
	def __init__(self):
		self.hues = []
		self.colores = []
		self.regiones = []
		self.satAverage = 0
		self.lumAverage = 0
		self.desvHue = 0
		self.avrHue = 0