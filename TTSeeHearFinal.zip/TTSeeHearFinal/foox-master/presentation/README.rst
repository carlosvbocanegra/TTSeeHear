Foox Presentation
=================

A copy of the HTML based presentation given at Europython 2012 in Florence,
Italy.

Uses the *really cool* Javascript presentation library ``reveal.js``
(https://github.com/hakimel/reveal.js) by Hakim El Hattab, http://hakim.se.
